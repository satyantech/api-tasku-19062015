<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 17-06-2015
 * Time: 10:50
 */

$type_name = $_REQUEST['type_name'];
$image = $_REQUEST['img'];

$sql = "INSERT INTO job_types(type_nm,background_img) VALUES('$type_name','$image')";

if($pdo->exec($sql)){
    echo json_encode(array('response'=>array(
        'code'=>'0x0000',
        'resp_msg'=>''
    )));
}else{
    echo json_encode(array('response'=>array(
        'code'=>'0x00DE',
        'resp_msg'=>'Data Storing Failed'
    )));
}