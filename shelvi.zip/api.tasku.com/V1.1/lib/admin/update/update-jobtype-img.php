<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 18-06-2015
 * Time: 13:22
 */


$rid = $_REQUEST['rid'];
$img = $_REQUEST['img'];

$sql = "UPDATE job_types SET background_img = '$img' WHERE id = $rid";

if($pdo->exec($sql)){
    echo json_encode(array('response'=>array('code'=>'0x0000','resp_msg'=>'')));
}else{
    echo json_encode(array('response'=>array('code'=>'0x000E','resp_msg'=>'Image could NOT be updated')));
}