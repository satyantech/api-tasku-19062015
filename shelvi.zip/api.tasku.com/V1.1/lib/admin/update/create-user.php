<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 15-06-2015
 * Time: 17:02
 */
include_once(__DIR__.'/../../../V1.1/lib/sec/encrypt-decrypt.php');
if(isset($_REQUEST['vals'])){
    $vals = json_decode($_REQUEST['vals']);


    //generating password
    $pwd            =   substr(strrev(uniqid()),0,8);
    $salt           =   substr(strrev(uniqid()),0,5);
    $pwd_encrypted  =   encrypt_decrypt('encrypt',$pwd,$salt);

    $pdo->beginTransaction();

    $sql = "INSERT INTO users(usr_type_id,prnt_usr_id,usr_nm,pwd,salt,status) VALUES(1,0,'$vals->email','$pwd_encrypted','$salt',1)";

    if($pdo->exec($sql)){
        $usr_id = $pdo->lastInsertId();
        if($usr_id > 0){
            $sql = "INSERT INTO admin_users(usr_id,fnm,mnm,lnm,pstl_addr,pstl_cd,city,state,country,cntct_num,email)";
        }else{
            $pdo->rollBack();
            echo json_encode(array('response'=>array('code'=>'0x0EUC','resp_msg'=>'Error while retriving the user data')));
        }
    }else{
        $pdo->rollBack();
        echo json_encode(array('response'=>array('code'=>'0x0URC','resp_msg'=>'User Record creation error.')));
    }

}else{
    echo json_encode(array('response'=>array('code'=>'0x00IP','resp_msg'=>'Invalid or No values sent for processing.')));
}

?>
