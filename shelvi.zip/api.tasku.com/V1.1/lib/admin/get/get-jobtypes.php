<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 16-06-2015
 * Time: 17:09
 */

$sql = "SELECT * FROM job_types ORDER BY id";
$stmt = $pdo->query($sql);

if($stmt){
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(array('response'=>array(
        'code'=>'0x0000',
        'resp_msg'=>'',
        'records'=>$records,
        'record_count'=>$stmt->rowCount()
    )));
}else{
    echo json_encode(array('response'=>array(
        'code'=>'0x00FR',
        'resp_msg'=>'No Records or Error while fetching records'
    )));
}