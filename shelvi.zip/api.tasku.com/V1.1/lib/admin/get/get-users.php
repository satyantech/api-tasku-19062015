<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 11-06-2015
 * Time: 17:14
 */

if(isset($_REQUEST['usr_id']) && $_REQUEST['usr_id'] && is_numeric($_REQUEST['usr_id'])){
    $sql = "
        SELECT
          au.usr_id USER_ID,
          u.usr_nm USER_NAME,
          au.fnm FIRST_NAME,
          au.mnm MIDDLE_NAME,
          au.lnm LAST_NAME,
          au.pstl_addr ADDRESS,
          au.pstl_cd POSTAL_CODE,
          au.city CITY,
          au.state STATE,
          au.country COUNTRY,
          au.cntct_num CELL_PHONE,
          au.email EMAIL
        FROM users u
        INNER JOIN admin_users au ON au.usr_id = u.id
        WHERE u.usr_type_id = 1
    ";
    $stmt = $pdo->query($sql);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if($stmt && $records){
        echo json_encode(array('response'=>array('code'=>'0x0000','resp_msg'=>'','records'=>$records)));
    }else{
        echo json_encode(array('response'=>array('code'=>'0x00DR','resp_msg'=>'Error While fetching records.')));
    }

}