<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 16-06-2015
 * Time: 15:09
 */

$sql = "SELECT
        u.id,
        org_id,
        usr_type_id,
        prnt_usr_id,
        usr_nm,
        pwd,
        salt,
        stts,
        usr_id,
        bsnss_nm,
        profile_pic,
        business_type,
        cntct_addr,
        cntr_id,
        stt_id,
        ct_id,
        pstl_cd,
        web_site,
        cntct_prsn_lnm,
        cntct_prsn_fnm,
        role,
        cntct_num1,
        cntct_num2,
        email1,
        email2,
        comp_desc,
        same_billing_addr,
        billing_addr,
        billing_name,
        billing_pstl_cd,
        billing_email,
        org_logo,
        bill_by_email,
        type_nm
        FROM users u
        INNER JOIN employer_details ed on ed.usr_id = u.id
        INNER JOIN business_types bt ON bt.id = ed.business_type
        WHERE u.usr_type_id = 3";
$stmt = $pdo->query($sql);
if($stmt){
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(array('response'=>array(
        'code'=>'0x0000',
        'resp_msg'=>'',
        'records'=>$records,
        'record_count'=>$stmt->rowCount()
    )));
}else{
    echo json_encode(array('response'=>array(
        'code'=>'0x00FR',
        'resp_msg'=>'No Records or Error while fetching records'
    )));
}