<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 18-06-2015
 * Time: 15:12
 */

$sql = "SELECT
        j.id JOB_ID,
        j.job_ttl JOB_TITLE,
        j.strt_dt START_DATE,
        j.end_dt END_DATE,
        j.min_pay EMPLOYEE_GET,
        j.max_pay EMPLOYER_GIVE,
        j.last_dt_appl APPLICATION_LAST_DATE,
        j.is_othr_org IS_DIFF_ORG,
        ed.bsnss_nm BUSINESS_NAME,
        j.othr_org_nm EMPLOYER_BUSINESS_NAME,
        j.posted_on POSTED_ON,
        jt.type_nm TYPE_NAME,
        jt.background_img BACKGROUND_IMG,
        j.is_active STATUS
        FROM jobs j
        INNER JOIN employer_details ed ON ed.usr_id = j.emplyr_id
        INNER JOIN job_types jt ON jt.id = j.job_type_id
        ORDER BY j.posted_on DESC,j.strt_dt DESC,j.end_dt
        ";

$stmt = $pdo->query($sql);
if($stmt){
    if($stmt->rowCount() > 0){
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(array('response'=>array('code'=>'0x0000','resp_msg'=>'','records'=>$records,'count'=>$stmt->rowCount())));
    }else{
        echo json_encode(array('response'=>array('code'=>'0x00E2','resp_msg'=>'No Records')));
    }
}else{
    echo json_encode(array('response'=>array('code'=>'0x00E1','resp_msg'=>'Error While Fetching Records')));
}