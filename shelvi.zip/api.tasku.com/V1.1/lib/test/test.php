<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 22-04-2015
 * Time: 21:58
 */
?>
{"response":{"code":"Test","resp_msg":"Test Successful"}}