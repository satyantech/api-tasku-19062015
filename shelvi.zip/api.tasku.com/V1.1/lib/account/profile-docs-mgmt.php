<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 02-06-2015
 * Time: 18:46
 */

if(isset($_REQUEST['usr_id']) && isset($_REQUEST['act']) && is_numeric($_REQUEST['usr_id']) && $_REQUEST['usr_id'] && $_REQUEST['act']){
    $act =  $_REQUEST['act'];
    $usr_id = $_REQUEST['usr_id'];
    if($act=='upload'){
        $file = $_REQUEST['prof_doc'];
        $file_type = $_REQUEST['prof_doc_type'];
        $sql = '';

        //echo
        $sql2 = "SELECT doc_path,count(id) cnt FROM worker_docs WHERE usr_id = $usr_id AND doc_type_id='$file_type'";
        $stmt2 = $pdo->query($sql2);
        $record = $stmt2->fetch(PDO::FETCH_ASSOC);
        //exit;
        if($record['cnt']==0) {
            $sql = "INSERT INTO worker_docs(usr_id,doc_type_id,doc_path) VALUES($usr_id,'$file_type','$file')";
        }else{
            $sql = "UPDATE worker_docs SET doc_path = '$file' WHERE usr_id = $usr_id AND doc_type_id='$file_type'";
        }
        if($sql!=''){
            if($pdo->exec($sql)){
                echo json_encode(array('response'=>array('code'=>'0x0000','resp_msg'=>'','oldfile'=>$record['doc_path'])));
            }else{
                echo json_encode(array('response'=>array('code'=>'0x00UF','resp_msg'=>'DB Error')));
            }
        }
    }else{
        $records = getDocuments($usr_id);
        echo json_encode(array('response'=>array('code'=>'0x0000','resp_msg'=>'','records'=>$records)));
    }
}
function getDocuments($usr_id){
    global $pdo;
    $sql = "SELECT usr_id USER_ID,doc_type_id DOC_TYPE,doc_path FILE FROM worker_docs WHERE usr_id = $usr_id";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
