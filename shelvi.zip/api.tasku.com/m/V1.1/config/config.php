<?php
	//Local
		$host 		= 'localhost';
		$database 	= 'gotasku';
		$user_name	= 'root';
		$password	= '';

	$pdo = null;
	try {
		$pdo = new PDO("mysql:host=localhost;dbname=$database;charset=utf8", $user_name, $password);
	} catch(PDOException $ex) {
		echo '{"result":["message":'.$ex->getMessage().']}';
		return;
	}
?>