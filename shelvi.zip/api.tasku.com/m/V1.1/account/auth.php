<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 12-06-2015
 * Time: 12:10
 */
include_once(__DIR__.'/../../../V1.1/lib/sec/encrypt-decrypt.php');

if(isset($req_json->device_token) && isset($req_json->password) && isset($req_json->phone)){

       $deviceToken = $req_json->device_token;
       $password = $req_json->password;
       $phone = $req_json->phone;

        $sql = "SELECT
                    u.id USER_ID,u.usr_nm USER_NAME,u.pwd PASSWORD,u.salt SALT,
                    rm.device_token DEVICE_TOKEN, rm.phone PHONE
                    FROM users u
                    INNER JOIN registered_mobiles rm ON rm.usr_id = u.id
                    WHERE rm.phone = '$phone' AND rm.device_token = '$deviceToken'";

        $stmt = $pdo->query($sql);

        if($stmt){
            if($stmt->rowCount()==1){
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                   $epwd = $row['PASSWORD'];
                   $salt = $row['SALT'];
                   $dpwd = encrypt_decrypt('decrypt', $epwd, $salt);

                if($dpwd == $password){
                    echo json_encode(array('response'=>array('code'=>'0x0000','status'=>'success','resp_msg'=>'','USER_ID'=>$row['USER_ID'])));
                }else{
                    echo json_encode(array('response'=>array('code'=>'0x00MM','status'=>'fail','resp_msg'=>'Invalid Credentials!')));
                }
            }else{
                echo json_encode(array('response'=>array('code'=>'0x00NR','status'=>'fail','resp_msg'=>'Record not found')));
            }
        }else{
            echo json_encode(array('response'=>array('code'=>'0x00FE','status'=>'fail','resp_msg'=>'Query Issue.')));
        }
}else{
    echo json_encode(array('response'=>array('code'=>'0x00IP','status'=>'fail','resp_msg'=>'Invalid Parameters')));
}