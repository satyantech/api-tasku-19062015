<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 12-06-2015
 * Time: 12:17
 */
include_once(__DIR__.'/../../../V1.1/lib/sec/encrypt-decrypt.php');
if($req_json->device_token && $req_json->password && $req_json->phone && $req_json->name){
    $pdo->beginTransaction();

    $deviceToken    =   $req_json->device_token;
    $pwd            =   $req_json->password;
    $phone          =   $req_json->phone;
    $name           =   $req_json->name;
    $photo          =   (isset($req_json->photo) && $req_json->photo)?$req_json->photo:'';

    //TODO: Validations

    $salt           =   substr(strrev(uniqid()),0,5);
    $pwd_encrypted  =   encrypt_decrypt('encrypt',$pwd,$salt);


    //standard values
    $usr_type_id    = 2; //Job Seekers
    $prnt_usr_id    = 0;
    $stts           = 1;
    //create user

    $sql = "INSERT INTO users(usr_type_id,prnt_usr_id,usr_nm,pwd,salt,stts) VALUES($usr_type_id,$prnt_usr_id,'$phone','$pwd_encrypted','$salt',$stts)";
    if($pdo->exec($sql)){
        $usr_id = $pdo->lastInsertId();
        $sql = "INSERT INTO worker_details(usr_id,fnm,profile_pic,cntct_num1) VALUES($usr_id,'$name','$photo','$phone')";
        if($pdo->exec($sql)){
            $sql = "INSERT INTO registered_mobiles(usr_id,phone,device_token,name) VALUES($usr_id,'$phone','$deviceToken','$name')";
            if($pdo->exec($sql)){
                $pdo->commit();
                echo json_encode(array('response'=>array('code'=>'0x0000','status'=>'success','resp_msg'=>'')));
            }else{
                $pdo->rollBack();
                echo json_encode(array('response'=>array('code'=>'0x00DE','status'=>'fail','resp_msg'=>'Device Registration failed')));
            }
        }else{ //if fails to enter into users table
            $pdo->rollBack();
            echo json_encode(array('response'=>array('code'=>'0x00UD','status'=>'fail','resp_msg'=>'Error while storing user details.')));
        }
    }else{ //if fails to enter into users table
        $pdo->rollBack();
        echo json_encode(array('response'=>array('code'=>'0x00EU','status'=>'fail','resp_msg'=>'Error while storing user data. Please check with the mobile number it might be duplicate',)));
    }
}else{
    echo json_encode(array('response'=>array('code'=>'0x00IC','status'=>'fail','resp_msg'=>'Invalid Call to API')));
}
