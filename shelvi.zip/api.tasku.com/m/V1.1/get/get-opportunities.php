<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 18-06-2015
 * Time: 16:41
 */

$user_id = $req_json->user_id;
$show_all = isset($req_json->show_all)?$req_json->show_all:0;
$rec_start = isset($req_json->rec_start_val)?$req_json->rec_start_val:0;
$num_records = isset($req_json->num_records)?$req_json->num_records:0;

$select = "SELECT ";
$select_fields = " j.id job_id,
        jt.type_nm job_type,
        jt.background_img background_image,
        jt.background_img bg_image,
        job_ttl job_title,
        resp resp,
        job_desc_sort desc_sort,
        job_desc_long desc_long,
        strt_dt start_date,
        end_dt end_date,
        min_pay emp_get,
        max_pay empr_give,
        shift_charges shift_charges_provided,
        is_active is_active,
        last_dt_appl apply_last_date,
        othr_org_nm employer_name,
        bt.type_nm employer_business,
        othr_org_addr addr,
        othr_org_pstl_cd postal_code,
        othr_org_phone contact,
        othr_org_website web_site,
        count(ap.id) has_applied ";
$select_count = "count(*) num_rows ";
$select_from = " FROM jobs j
INNER JOIN job_skills js ON js.job_id = j.id
INNER JOIN worker_skills ws ON ws.skill = js.skill
INNER JOIN job_types jt ON jt.id = j.job_type_id
INNER JOIN business_types bt ON j.othr_org_bsnss = bt.id
LEFT JOIN applications ap on ap.job_id = j.id and ap.wrkr_id = ws.wrkr_id
WHERE ws.wrkr_id =".$user_id;
$select_group_by = " group by j.id ";

$select_limits = "";

if(!$show_all){
    $select_limits = " LIMIT $rec_start,$num_records";
}

$count_sql = $select.$select_count.$select_from.$select_group_by;
$count_stmt = $pdo->query($count_sql);
$total_rows = $count_stmt->rowCount();


$sql = $select.$select_fields.$select_from.$select_group_by.$select_limits;
$stmt = $pdo->query($sql);





if($stmt){
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(array('response'=>array('code'=>'0x0000','status'=>'success','resp_msg'=>'','records'=>$records,'total_rows'=>"$total_rows")));
}else{
    echo json_encode(array('response'=>array('code'=>'0x00NR','status'=>'fail','resp_msg'=>'No Records... ')));
}