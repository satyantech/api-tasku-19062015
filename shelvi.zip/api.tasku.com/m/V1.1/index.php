<?php
/**
 * Created by PhpStorm.
 * User: Satyanarayan
 * Date: 22-04-2015
 * Time: 17:21
 */
include_once(__DIR__.'/../../V1.1/config/config.php');
$called_path = '';
if(isset($_POST['req']) && $_POST['req']!=''){
    $request_str = $_POST['req'];
    try{
        $req_json = json_decode($request_str);
        /**
         * FOR REQUESTING ANY API DEVICE TOKEN IS A MUST
         */
        if (!isset($req_json->device_token) || trim($req_json->device_token) == '') {
            echo json_encode(array('response' => array('code' => '0x0DTM', 'status' => 'fail', 'resp_msg' => 'Device Token Missing!!')));
            exit;
        }

        if($req_json->a){
            /**
             *  IF THE REQUEST IS COMING FOR ANY API EXCEPT account THEN user_id PARAMETER IS MANDATORY
             */
            if($req_json->a != 'account') {
                if (!isset($req_json->user_id) || trim($req_json->user_id) == '') {
                    echo json_encode(array('response' => array('code' => '0x0UIM', 'status' => 'fail', 'resp_msg' => 'User ID Missing!!')));
                    exit;
                }
                if(!isValidUser($req_json->user_id,$req_json->device_token)){
                    echo json_encode(array('response'=>array('code'=>'0x00IU','status'=>'fail','resp_msg'=>'Invalid user or device for the user...')));
                    exit;
                }
            }
            /**
             * PARAMETER a REPRESENTS THE DIRECTORY IN WHICH THE CODE FILE RESIDES
             */
            $called_path = __DIR__.'/'.$req_json->a.'/';

            if($req_json->sa){
                /**
                 * THE PARAMETER sa REPRESENTS THE FILE TO BE TAKEN FOR EXECUTION
                 */
                $called_path .= $req_json->sa.'.php';
                /**
                 * IF THE REQUESTED API (PHYSICAL FILE) CAN NOT BE MAPPED THEN 0X0003 IS SENT AS STATUS CODE
                 */
                if(file_exists($called_path)) include_once($called_path);
                else echo json_encode(array('response'=>array('code'=>'0x0003','status'=>'fail','resp_msg'=>'Invalid parameters sent for processing...')));
            }else{
                /**
                 * IF THE REQUEST COMES WITH AN MISSING sa PARAMETER
                 */
                echo json_encode(array('response'=>array('code'=>'0x0002','status'=>'fail','resp_msg'=>'Invalid set of parameters sent for processing...')));
            }
        }else{
            /**
             * IF THE REQUEST COMES WITH AN MISSING a PARAMETER
             */
            echo json_encode(array('response'=>array('code'=>'0x0001','status'=>'fail','resp_msg'=>'Invalid set of parameters sent for processing...')));
        }

    }catch(Exception $ex){
        /**
         * IF ANY EXCEPTION OCCURS
         */
        echo json_encode(array('response'=>array('code'=>'0x000A','ststus'=>'fail','resp_msg'=>'Please check REQUEST format/data')));
    }
}else{
    echo 'It seems some things not right.';
}

/**
 * THIS METHOD CHECKS FOR THE VALIDITY IF GIVEN user_id IS MATCHED WITH device_token
 * @param $UserID
 * @param $DeviceToken
 * @return bool
 */
function isValidUser($UserID,$DeviceToken){
    global $pdo;
    $sql = "SELECT * FROM registered_mobiles WHERE usr_id = $UserID AND device_token = '$DeviceToken'";
    $stmt = $pdo->query($sql);
    if($stmt){
        if($stmt->rowCount() == 1) return true;
        else return false;
    }else{
        return false;
    }
}
?>

